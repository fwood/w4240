function message = get_message_fn_b(to_node)

message = [.001 ;.999];