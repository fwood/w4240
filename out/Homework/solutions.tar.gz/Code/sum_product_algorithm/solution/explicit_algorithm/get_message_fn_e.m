function message = get_message_fn_e(to_node)

message = [.002; .998];